// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  // Setting max buffer amount
  const int bufferMax = 20;

  std::cout << "Enter a value: ";
  //using getline to capture only the bufferMax amount
  std::cin.getline(user_input, bufferMax);

  //if the userinput is greater than the bufferMax it will let the user know 
  //that they have entered in to much data and the amount that can be entered
  if (!std::cin) {
    //lets the user know the error
    std::cout<<"YOU HAVE ENTERED TO MUCH DATA" << std::endl;
    std::cout<<"Input must be 20 characters or less" << std::endl;

    //clearing the error 
    std::cin.clear();
    
  }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
